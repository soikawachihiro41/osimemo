(() => {
  // app/javascript/image_composite.js
  document.addEventListener("DOMContentLoaded", function() {
    const imageUpload = document.getElementById("image-upload");
    const overlayOptions = document.getElementById("overlay-options");
    const xOffsetInput = document.getElementById("x-offset");
    const yOffsetInput = document.getElementById("y-offset");
    const widthInput = document.getElementById("width");
    const heightInput = document.getElementById("height");
    imageUpload.addEventListener("change", function(event) {
    });
    overlayOptions.addEventListener("change", function(event) {
    });
  });
})();

